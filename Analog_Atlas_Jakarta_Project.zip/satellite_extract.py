# SI-assisted code: OpenAI Codex. See PROVENANCE.json.
"""Bounded Earthdata extraction for EMIT V001, MOD11A1.061, MOD10A1.61.

Native pixel centers are clipped to the candidate polygon. QA decisions and
source files are retained. No field review or planetary mineral match is inferred.
"""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import re
from urllib.parse import urlparse
import numpy as np

DEFAULTS = dict(max_emit_scenes=3, max_modis_days=12, max_catalog_items=2000,
                max_thermal_days=60, target_thermal_summaries=24, target_thermal_months=6,
                max_download_gb=2.0, max_file_mb=300, emit_fit_min=.8,
                emit_fit_multiplier=2.0, emit_min_depth_sigma=3.0,
                emit_min_detection_pixels=3, lst_max_error_code=0,
                lst_max_emissivity_error_code=1, snow_max_basic_qa=1,
                snow_reject_bits=[0,1,2,3,4,5,7], snow_ndsi_threshold=40,
                minimum_valid_fraction=.1)
CMR='https://cmr.earthdata.nasa.gov/search/granules.json'

def save(path,value):
    Path(path).write_text(json.dumps(value,indent=2,allow_nan=False),encoding='utf-8')

def error_detail(error):
    result={'type':type(error).__name__}
    if isinstance(error,StopIteration):result['reason']='Required companion file link missing from the catalog.'
    elif isinstance(error,KeyError):result['reason']='Required data variable or metadata key is missing.'
    elif isinstance(error,ValueError):result['reason']=str(error)[:240]
    if getattr(error,'response',None) is not None:result['http_status']=error.response.status_code
    return result

def clean_array(variable, key=slice(None)):
    return np.ma.asarray(variable[key],dtype=float).filled(np.nan)

def pixel_roi(lon,lat,polygon):
    from shapely import contains_xy
    from shapely.geometry import Polygon
    return np.isfinite(lon)&np.isfinite(lat)&contains_xy(Polygon(polygon),lon,lat)

def lst_mask(raw,qc,roi,config):
    qc=np.asarray(qc,dtype=np.uint16)
    return (roi & np.isfinite(raw) & (raw>=7500)&(raw<=65535)
            & ((qc&3)==0)&(((qc>>2)&3)==0)
            & (((qc>>4)&3)<=config['lst_max_emissivity_error_code'])
            & (((qc>>6)&3)<=config['lst_max_error_code']))

def lst_audit(raw,qc,roi,config,fill=None):
    """Sequential, exclusive pixel losses. QA thresholds are unchanged."""
    qc=np.asarray(qc,dtype=np.uint16)
    stages=[('valid_raw_range',np.isfinite(raw)&(raw>=7500)&(raw<=65535)),
            ('mandatory_good',(qc&3)==0),('data_quality_good',((qc>>2)&3)==0),
            ('emissivity_error',((qc>>4)&3)<=config['lst_max_emissivity_error_code']),
            ('temperature_error',((qc>>6)&3)<=config['lst_max_error_code'])]
    if fill is not None:stages[0]=(stages[0][0],stages[0][1]&(raw!=fill))
    keep=roi.copy();losses={};remaining={'roi_pixels':int(keep.sum())}
    for name,screen in stages:
        previous=int(keep.sum());keep &= screen
        remaining[name]=int(keep.sum());losses[name]=previous-int(keep.sum())
    return keep,{'remaining':remaining,'exclusive_losses':losses,
                 'mandatory_qc_codes_in_roi':{str(v):int(np.sum(roi&((qc&3)==v))) for v in range(4)}}

def thermal_date_order(entries,initial,maximum):
    """Keep the original evenly spaced dates, then fill the largest date gaps."""
    dates=sorted({e['time_start'][:10] for e in entries})
    if not dates:return []
    selected=list(dict.fromkeys(dates[i] for i in np.linspace(0,len(dates)-1,min(initial,len(dates)),dtype=int)))
    day=lambda s:datetime.fromisoformat(s).toordinal()
    while len(selected)<min(maximum,len(dates)):
        remaining=[d for d in dates if d not in selected]
        best=max(remaining,key=lambda d:(min(abs(day(d)-day(s)) for s in selected),-day(d)))
        selected.append(best)
    return selected[:maximum]

def summary_reason(roi,valid,fraction,incomplete,minimum):
    if incomplete:return 'incomplete_tiles'
    if not roi:return 'no_pixels_inside_polygon'
    if not valid:return 'no_pixels_passed_QA'
    if fraction<minimum:return 'below_valid_fraction'
    return 'accepted'

def coverage_diagnosis(detail,minimum_valid_fraction=.1):
    rows=detail.get('observations',[])
    reasons=Counter(r.get('rejection_reason') or ('accepted' if r.get('accepted') else summary_reason(r.get('roi_pixels',0),r.get('valid_pixels',0),r.get('valid_fraction',0),r.get('incomplete_tiles',False),minimum_valid_fraction)) for r in rows)
    losses=Counter()
    for row in rows:losses.update(row.get('qa_exclusive_losses',{}))
    accepted=[r for r in rows if r.get('accepted')]
    return {'accepted_summaries':len(accepted),'accepted_days':len({r.get('date') for r in accepted}),
            'accepted_months':sorted({r['date'][:7] for r in accepted if r.get('date')}),
            'summary_outcomes':dict(reasons),'exclusive_pixel_QA_losses':dict(losses),
            'failed_granules':len(detail.get('errors',[])),
            'note':'Older manifests lack pixel rejection counts. Missing diagnostics cannot establish why old pixels were lost.'}

def snow_mask(ndsi,basic,flags,roi,config):
    reject=sum(1<<b for b in set(config['snow_reject_bits']))
    return (roi & (ndsi>=0)&(ndsi<=100)&(basic<=config['snow_max_basic_qa'])
            & ((flags.astype(np.uint16)&reject)==0))

def emit_detection_mask(ids,depth,uncertainty,fit,clear,config):
    fit=fit*config['emit_fit_multiplier']
    return (clear & np.isfinite(ids)&(ids>0)&np.isfinite(depth)&(depth>0)
            & np.isfinite(uncertainty)&(uncertainty>0)
            & (depth>=config['emit_min_depth_sigma']*uncertainty)
            & np.isfinite(fit)&(fit>=config['emit_fit_min'])&(fit<=1.00001))

def catalog(short_name,version,bbox,start,end,limit,producer=None):
    import requests
    params={'short_name':short_name,'version':version,'page_size':limit,'sort_key':'start_date'}
    if producer:params['granule_ur']=producer
    else:params.update(bounding_box=','.join(map(str,bbox)),temporal=f'{start}T00:00:00Z,{end}T23:59:59Z')
    response=requests.get(CMR,params=params,timeout=(15,60));response.raise_for_status()
    entries=response.json()['feed']['entry'];hits=int(response.headers.get('CMR-Hits',len(entries)))
    if hits>limit:raise ValueError('Catalog exceeds configured cap; shorten the date range or increase max_catalog_items.')
    return entries

def data_urls(entry):
    return sorted(set(l['href'] for l in entry.get('links',[]) if not l.get('inherited')
        and l.get('rel','').endswith('/data#') and l.get('href','').startswith('https://')
        and urlparse(l['href']).path.lower().endswith(('.nc','.hdf'))))

def select_days(entries,maximum):
    """Spread observations across the available dates; retain every tile that day."""
    dates=sorted(set(e['time_start'][:10] for e in entries))
    selected={dates[i] for i in np.unique(np.linspace(0,len(dates)-1,min(maximum,len(dates)),dtype=int))} if dates else set()
    # Deduplicate archive copies by product/date/tile; use latest processing name.
    unique={}
    for entry in entries:
        if entry['time_start'][:10] not in selected:continue
        for url in data_urls(entry):
            name=Path(urlparse(url).path).name
            if not name.endswith('.hdf'):continue
            key='.'.join(name.split('.')[:4])
            if key not in unique or name>unique[key][0]:unique[key]=(name,entry,url)
    return [(v[1],v[2]) for _,v in sorted(unique.items())]

class Downloader:
    def __init__(self,session,directory,config):
        self.session=session;self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=True)
        self.config=config;self.bytes=0;self.assets={}
        if hasattr(session,'mount'):
            from requests.adapters import HTTPAdapter
            from urllib3.util.retry import Retry
            session.mount('https://',HTTPAdapter(max_retries=Retry(total=2,backoff_factor=1,
                status_forcelist=[429,500,502,503,504],allowed_methods=['GET'],respect_retry_after_header=True)))
    def fetch(self,url):
        parsed=urlparse(url)
        if parsed.scheme!='https' or not (parsed.hostname.endswith('.nasa.gov') or parsed.hostname.endswith('.nsidc.org') or parsed.hostname=='nsidc.org'):
            raise ValueError('Unexpected Earthdata download host')
        name=Path(parsed.path).name
        path=self.directory/name
        cap=int(self.config['max_file_mb']*1e6)
        if not path.exists():
            part=path.with_suffix(path.suffix+'.part')
            try:
                with self.session.get(url,stream=True,timeout=(20,90)) as response:
                    response.raise_for_status()
                    if 'text/html' in response.headers.get('Content-Type',''):raise ValueError('Login page returned instead of data')
                    expected=int(response.headers.get('Content-Length',0))
                    if expected>cap:raise ValueError('File exceeds max_file_mb')
                    size=0
                    with part.open('wb') as stream:
                        for block in response.iter_content(1024*1024):
                            size+=len(block);self.bytes+=len(block)
                            if size>cap or self.bytes>self.config['max_download_gb']*1e9:raise ValueError('Download budget exceeded')
                            stream.write(block)
                    if expected and size!=expected:raise ValueError('Incomplete download')
                    part.replace(path)
            finally:
                if part.exists():part.unlink()
        # Reject HTML/error cache entries; HDF4 or HDF5/NetCDF4 signatures only.
        with path.open('rb') as stream:
            signature=stream.read(8)
            if not (signature.startswith(b'\x0e\x03\x13\x01') or signature==b'\x89HDF\r\n\x1a\n'):
                raise ValueError('Cached file is not HDF4/NetCDF4; remove this cached file and retry')
            stream.seek(0);digest=hashlib.file_digest(stream,'sha256').hexdigest()
        self.assets[url]={'url':url,'file':name,'bytes':path.stat().st_size,'sha256':digest}
        return path

def modis_window(sd,shape,polygon):
    """Read sinusoidal HDF-EOS bounds, then mask exact geographic pixel centers."""
    from pyproj import CRS,Transformer
    attrs=sd.attributes();meta=''.join(str(attrs[k]) for k in sorted(attrs) if k.startswith('StructMetadata.'))
    if 'GCTP_SNSOID' not in meta:raise ValueError('Expected MODIS sinusoidal grid')
    def pair(name):
        match=re.search(name+r'\s*=\s*\(([^)]+)\)',meta)
        if not match:raise ValueError('Missing HDF-EOS grid bounds')
        return [float(v) for v in match[1].split(',')]
    left,top=pair('UpperLeftPointMtrs');right,bottom=pair('LowerRightMtrs')
    params=pair('ProjParams');radius=params[0] if params[0]>0 else 6371007.181
    crs=CRS.from_proj4(f'+proj=sinu +R={radius} +units=m +no_defs')
    forward=Transformer.from_crs('EPSG:4326',crs,always_xy=True)
    inverse=Transformer.from_crs(crs,'EPSG:4326',always_xy=True)
    edge=[]
    for a,b in zip(polygon[:-1],polygon[1:]):
        edge.extend([(a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])) for t in np.linspace(0,1,33)])
    x,y=forward.transform(*np.array(edge).T)
    height,width=shape;dx=(right-left)/width;dy=(top-bottom)/height
    c0=max(0,int(math.floor((min(x)-left)/dx)));c1=min(width,int(math.ceil((max(x)-left)/dx)))
    r0=max(0,int(math.floor((top-max(y))/dy)));r1=min(height,int(math.ceil((top-min(y))/dy)))
    if c1<=c0 or r1<=r0:return None
    xx,yy=np.meshgrid(left+(np.arange(c0,c1)+.5)*dx,top-(np.arange(r0,r1)+.5)*dy)
    lon,lat=inverse.transform(xx,yy)
    return (slice(r0,r1),slice(c0,c1)),pixel_roi(lon,lat,polygon)

def extract_modis(path,kind,polygon,config):
    from pyhdf.SD import SD,SDC
    sd=SD(str(path),SDC.READ)
    try:
        first=sd.select('LST_Day_1km' if kind=='thermal' else 'NDSI_Snow_Cover')
        shape=first.info()[2];first.endaccess()
        window=modis_window(sd,shape,polygon)
        if window is None:return []
        slices,roi=window
        def get(name):
            variable=sd.select(name)
            try:return np.array(variable[slices]),variable.attributes()
            finally:variable.endaccess()
        results=[]
        if kind=='thermal':
            for period in ['Day','Night']:
                raw,attrs=get(f'LST_{period}_1km');qc,_=get(f'QC_{period}')
                valid,audit=lst_audit(raw,qc,roi,config,attrs.get('_FillValue'))
                scale=float(attrs.get('scale_factor',.02));offset=float(attrs.get('add_offset',0))
                if not np.isclose(scale,.02) or offset!=0:raise ValueError('Unexpected MOD11 scale/offset')
                values=(raw[valid].astype(float)*scale-273.15).tolist()
                results.append({'period':period,'roi_pixels':int(roi.sum()),'valid_pixels':int(valid.sum()),'values_c':values,'qa_audit':audit})
        else:
            ndsi,_=get('NDSI_Snow_Cover');basic,_=get('NDSI_Snow_Cover_Basic_QA');flags,_=get('NDSI_Snow_Cover_Algorithm_Flags_QA')
            valid=snow_mask(ndsi,basic,flags,roi,config)
            results.append({'period':'Day','roi_pixels':int(roi.sum()),'valid_pixels':int(valid.sum()),
                            'snow_pixels':int(np.sum(valid&(ndsi>=config['snow_ndsi_threshold'])))})
        return results
    finally:sd.end()

def extract_emit(min_path,unc_path,mask_path,polygon,config):
    from netCDF4 import Dataset
    with Dataset(min_path) as minerals,Dataset(unc_path) as uncertainty,Dataset(mask_path) as masks:
        loc=minerals.groups['location'];lat=clean_array(loc['lat']);lon=clean_array(loc['lon'])
        roi=pixel_roi(lon,lat,polygon)
        # Companion files must represent identical native detector geometry.
        for dataset in [uncertainty,masks]:
            other=dataset.groups['location']
            if other['lat'].shape!=lat.shape or not np.allclose(clean_array(other['lat'])[roi],lat[roi],atol=1e-6,equal_nan=True) or not np.allclose(clean_array(other['lon'])[roi],lon[roi],atol=1e-6,equal_nan=True):
                raise ValueError('EMIT companion geolocation mismatch')
        labels=[str(v).lower() for v in masks.groups['sensor_band_parameters']['mask_bands'][:]]
        if len(labels)<8 or not all(token in labels[i] for i,token in enumerate(['cloud','cirrus','water','spacecraft','dilated'])):
            raise ValueError('Unsupported EMIT mask layout; V001 required')
        clear=roi.copy()
        # Flag bands only; aerosol/water-vapor values at 5/6 are not binary flags.
        for index in [0,1,2,3,4,7]:clear &= clean_array(masks['mask'],(slice(None),slice(None),index))==0
        metadata=minerals.groups['mineral_metadata']
        names={int(i):str(n) for i,n in zip(metadata['index'][:],metadata['name'][:])}
        counts=Counter();group_stats=[]
        for group in [1,2]:
            prefix=f'group_{group}_'
            ids=clean_array(minerals[prefix+'mineral_id']);depth=clean_array(minerals[prefix+'band_depth'])
            unc=clean_array(uncertainty[prefix+'band_depth_unc']);fit=clean_array(uncertainty[prefix+'fit'])
            accepted=emit_detection_mask(ids,depth,unc,fit,clear,config)
            found,cnt=np.unique(ids[accepted].astype(int),return_counts=True)
            for ident,count in zip(found,cnt):
                if ident not in names:raise ValueError('Mineral ID absent from file metadata')
                counts[names[ident]]+=int(count)
            group_stats.append({'group':group,'accepted_detection_pixels':int(accepted.sum())})
        return {'roi_pixels':int(roi.sum()),'clear_pixels':int(clear.sum()),'counts':dict(counts),'groups':group_stats}

def run_extraction(candidate,start,end,session,directory,config=None):
    cfg={**DEFAULTS,**(config or {})}
    if cfg['max_emit_scenes']<1 or cfg['max_modis_days']<1:raise ValueError('Download limits must be positive')
    if not 0<cfg['minimum_valid_fraction']<=1:raise ValueError('minimum_valid_fraction must be in (0,1]')
    polygon=candidate['footprint'];box=[min(p[0] for p in polygon),min(p[1] for p in polygon),max(p[0] for p in polygon),max(p[1] for p in polygon)]
    if box[2]-box[0]>180:raise ValueError('Split date-line-crossing polygons before extraction')
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    previous=None
    previous_path=directory/'extraction_manifest.json'
    if previous_path.exists():
        old=json.loads(previous_path.read_text(encoding='utf-8'))
        if old.get('candidate_id')==candidate['id'] and old.get('period')==[start,end]:
            previous=coverage_diagnosis(old.get('products',{}).get('thermal',{}),old.get('settings',{}).get('minimum_valid_fraction',.1))
            save(directory/'previous_extraction_manifest.json',old)
    dl=Downloader(session,directory/'downloads',cfg)
    report={'candidate_id':candidate['id'],'period':[start,end],'settings':cfg,
            'created_utc':datetime.now(timezone.utc).isoformat(),'products':{},'assets':[]}
    report['packages']={name:importlib.metadata.version(name) for name in ['numpy','netCDF4','pyhdf','pyproj','shapely']}
    report['selection_note']='EMIT scenes and MODIS dates sampled across available catalog results; all returned MODIS tiles retained for each selected date. No claim of full-year or full-patch valid coverage.'
    report['previous_thermal_diagnosis']=previous
    observations={}
    def base(method,urls):
        return dict(candidate_id=candidate['id'],source_urls=sorted(set(urls)),period=f'{start}/{end}',method=method,
                    qa_reviewed=False,qa_processed=True,processing='satellite_extract_v1',field_validated=False)
    for kind,product,version in [('thermal','MOD11A1','061'),('ice','MOD10A1','61'),('minerals','EMITL2BMIN','001')]:
        print(f'Extracting {product}...',flush=True)
        detail={'status':'STARTED','errors':[],'observations':[]};report['products'][kind]=detail
        used_urls=[];values=[];fractions=[];mineral_counts=Counter();groups=defaultdict(list)
        try:
            entries=catalog(product,version,box,start,end,cfg['max_catalog_items'])
            detail['catalog_count']=len(entries)
            if kind=='minerals':
                picks=np.unique(np.linspace(0,len(entries)-1,min(cfg['max_emit_scenes'],len(entries)),dtype=int)) if entries else []
                detail['selected_granules']=len(picks)
                for index in picks:
                    entry=entries[index]
                    try:
                        urls=data_urls(entry)
                        min_url=next(u for u in urls if Path(urlparse(u).path).name.startswith('EMIT_L2B_MIN_001_'))
                        unc_url=next(u for u in urls if Path(urlparse(u).path).name.startswith('EMIT_L2B_MINUNCERT_001_'))
                        suffix=Path(urlparse(min_url).path).name.split('EMIT_L2B_MIN_001_')[1].removesuffix('.nc')
                        companion=catalog('EMITL2ARFL','001',box,start,end,50,'EMIT_L2A_RFL_001_'+suffix)
                        mask_url=next(u for e in companion for u in data_urls(e) if Path(urlparse(u).path).name=='EMIT_L2A_MASK_001_'+suffix+'.nc')
                        paths=[dl.fetch(u) for u in [min_url,unc_url,mask_url]]
                        result=extract_emit(*paths,polygon,cfg)
                        result.update(granule=entry.get('title',entry['id']),time=entry['time_start'])
                        result['accepted_scene']=result['roi_pixels']>0 and result['clear_pixels']/max(1,result['roi_pixels'])>=cfg['minimum_valid_fraction']
                        detail['observations'].append(result)
                        if result['accepted_scene']:
                            mineral_counts.update(result['counts']);used_urls.extend([min_url,unc_url,mask_url])
                    except Exception as error:
                        detail['errors'].append({'granule':entry['id'],**error_detail(error),'stage':'EMIT companion/download/extraction'})
                names=sorted(n for n,c in mineral_counts.items() if c>=cfg['emit_min_detection_pixels'])
                record=base('Native EMIT pixel centers clipped to polygon; V001 mask flags 0,1,2,3,4,7 clear; positive detections; band depth >= configured sigma * uncertainty; fit * 2 >= configured minimum. Counts are pixel-detections, not mineral abundance.',used_urls)
                record.update(earth_minerals=names,target_minerals=[],cross_sensor_reviewed=False,mineral_pixel_detections=dict(mineral_counts))
                has_values=bool(names)
            else:
                selected=select_days(entries,len(entries) or 1) if kind=='thermal' else select_days(entries,cfg['max_modis_days'])
                if kind=='thermal':
                    order=thermal_date_order(entries,cfg['max_modis_days'],cfg['max_thermal_days'])
                    selected=sorted([(e,u) for e,u in selected if e['time_start'][:10] in order],key=lambda pair:order.index(pair[0]['time_start'][:10]))
                    detail['planned_dates']=order
                detail['selected_granules']=len(selected)
                failed_dates=set()
                attempted_dates=[];accepted_so_far=[];stop_reason='date_limit_or_available_dates'
                for position,(entry,url) in enumerate(selected):
                    date=entry['time_start'][:10]
                    if date not in attempted_dates:
                        if kind=='thermal' and len(attempted_dates)>=cfg['max_modis_days']:
                            accepted_so_far=[key for key,parts in groups.items() if summary_reason(
                                sum(p['roi_pixels'] for p,u in parts),sum(p['valid_pixels'] for p,u in parts),
                                sum(p['valid_pixels'] for p,u in parts)/max(1,sum(p['roi_pixels'] for p,u in parts)),
                                key[0] in failed_dates,cfg['minimum_valid_fraction'])=='accepted']
                            if len(accepted_so_far)>=cfg['target_thermal_summaries'] and len({key[0][:7] for key in accepted_so_far})>=cfg['target_thermal_months']:
                                stop_reason='coverage_targets_met';break
                        if dl.bytes>=cfg['max_download_gb']*1e9:
                            stop_reason='download_budget';break
                        attempted_dates.append(date)
                    try:
                        path=dl.fetch(url)
                        parts=extract_modis(path,'thermal' if kind=='thermal' else 'ice',polygon,cfg)
                        for part in parts:
                            key=(entry['time_start'][:10],part['period']);groups[key].append((part,url))
                    except Exception as error:
                        failed_dates.add(entry['time_start'][:10])
                        detail['errors'].append({'granule':entry['id'],**error_detail(error),'stage':'MODIS download/extraction'})
                        detail['errors'][-1]['date']=date
                detail['attempted_dates']=attempted_dates;detail['stop_reason']=stop_reason
                for date in attempted_dates:
                    for period in (['Day','Night'] if kind=='thermal' else ['Day']):groups.setdefault((date,period),[])
                for (date,period),parts in sorted(groups.items()):
                    roi=sum(p['roi_pixels'] for p,u in parts);valid=sum(p['valid_pixels'] for p,u in parts)
                    item={'date':date,'period':period,'roi_pixels':roi,'valid_pixels':valid,'valid_fraction':valid/max(1,roi)}
                    item['incomplete_tiles']=date in failed_dates
                    item['accepted']=valid>0 and not item['incomplete_tiles'] and item['valid_fraction']>=cfg['minimum_valid_fraction']
                    item['rejection_reason']=summary_reason(roi,valid,item['valid_fraction'],item['incomplete_tiles'],cfg['minimum_valid_fraction'])
                    if kind=='thermal':
                        qa_losses=Counter()
                        for p,u in parts:qa_losses.update(p.get('qa_audit',{}).get('exclusive_losses',{}))
                        item['qa_exclusive_losses']=dict(qa_losses)
                        local=[v for p,u in parts for v in p['values_c']]
                        if local:item.update(min_c=min(local),max_c=max(local),mean_c=float(np.mean(local)))
                        if item['accepted']:values.extend(local)
                    else:
                        snow=sum(p['snow_pixels'] for p,u in parts)
                        item['snow_fraction_of_valid_pixels']=snow/valid if valid else None
                        if item['accepted']:fractions.append(snow/valid)
                    if item['accepted']:used_urls.extend(u for p,u in parts)
                    detail['observations'].append(item)
                if kind=='thermal':
                    detail['diagnosis']=coverage_diagnosis(detail,cfg['minimum_valid_fraction'])
                    save(directory/'temperature_coverage.json',{'previous':previous,'current':detail['diagnosis'],
                        'attempted_dates':attempted_dates,'stop_reason':stop_reason,'errors':detail['errors'],
                        'quality_masks_relaxed':False,'settings':cfg})
                    print('Temperature coverage:',json.dumps(detail['diagnosis']),flush=True)
                record=base('MODIS native sinusoidal pixel centers clipped to polygon; fill, valid-range and product-specific QA applied. Selected dates evenly spaced across available observations; not a full climatology.',used_urls)
                if kind=='thermal':
                    record.update(surface_temperature_c=values,sample_unit='valid pixel-observations',
                                  observation_count=sum(o['accepted'] for o in detail['observations']))
                    has_values=bool(values)
                else:
                    record.update(snow_cover_fraction=fractions,snow_ndsi_threshold=cfg['snow_ndsi_threshold'],
                                  fraction_definition='Fraction of QA-valid observed pixels with NDSI_Snow_Cover >= threshold. NDSI itself is not fractional snow cover.')
                    has_values=bool(fractions)
            if has_values:status='AUTO_QA_MEASURED'
            elif not entries:status='NO_GRANULES'
            elif detail['errors'] and detail['observations'] and all(r.get('incomplete_tiles') for r in detail['observations']):status='EXTRACTION_FAILED'
            elif detail['observations']:status='NO_ACCEPTED_MEASUREMENTS'
            else:status='EXTRACTION_FAILED'
            detail['status']=status;record['extraction_status']=status
            if not has_values:record['qa_processed']=False
            observations[kind]=record
        except Exception as error:
            detail.update(status='EXTRACTION_FAILED',error=error_detail(error))
            observations[kind]={**base('Extraction did not complete.',[]),'qa_processed':False,'extraction_status':'EXTRACTION_FAILED'}
        # Preserve partial results if a later product fails.
        report['assets']=list(dl.assets.values());save(directory/'extraction_manifest.json',report)
        save(directory/'automatic_observations.json',observations)
        print(kind+': '+detail['status'],flush=True)
    observations['construction']=dict(observations['minerals'])
    save(directory/'automatic_observations.json',observations)
    return observations,report
