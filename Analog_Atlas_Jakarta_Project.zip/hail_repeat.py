# SI-assisted code: OpenAI Codex. See PROVENANCE.json.
"""Ha'il repeat EMIT screening. Regional inspection areas, never approved routes."""
from collections import defaultdict
from pathlib import Path
from datetime import datetime, timezone
import html
import json
import numpy as np
import pandas as pd
from pyproj import Transformer
import satellite_extract as core

CRS = '+proj=aeqd +lat_0=27.5 +lon_0=41.5 +datum=WGS84 +units=m +no_defs'
FORWARD = Transformer.from_crs('EPSG:4326', CRS, always_xy=True)
INVERSE = Transformer.from_crs(CRS, 'EPSG:4326', always_xy=True)

def spatial_scene(paths, polygon, cfg):
    """Reuse original scene/geolocation validation and EXACT pixel QA functions."""
    from netCDF4 import Dataset
    audit = core.extract_emit(*paths, polygon, cfg)
    audit['accepted_scene'] = audit['roi_pixels'] > 0 and audit['clear_pixels']/max(1,audit['roi_pixels']) >= cfg['minimum_valid_fraction']
    if not audit['accepted_scene']: return audit, [], []
    with Dataset(paths[0]) as m, Dataset(paths[1]) as u, Dataset(paths[2]) as k:
        lat=core.clean_array(m.groups['location']['lat']);lon=core.clean_array(m.groups['location']['lon'])
        clear=core.pixel_roi(lon,lat,polygon)
        for i in [0,1,2,3,4,7]:clear &= core.clean_array(k['mask'],(slice(None),slice(None),i))==0
        x,y=FORWARD.transform(lon[clear],lat[clear])
        coverage=np.column_stack([x,y]).tolist()
        md=m.groups['mineral_metadata'];names={int(i):str(n) for i,n in zip(md['index'][:],md['name'][:])}
        points=[]
        for group in [1,2]:
            p=f'group_{group}_'
            ids=core.clean_array(m[p+'mineral_id'])
            good=core.emit_detection_mask(ids,core.clean_array(m[p+'band_depth']),core.clean_array(u[p+'band_depth_unc']),core.clean_array(u[p+'fit']),clear,cfg)
            x,y=FORWARD.transform(lon[good],lat[good])
            for xx,yy,ident in zip(x,y,ids[good].astype(int)):
                name=names[ident]
                # Additional conservative scene-level support, not a weaker mask.
                if audit['counts'][name]>=cfg['emit_min_detection_pixels']:
                    points.append([float(xx),float(yy),name])
    return audit,coverage,points

def aggregate(scenes, grid_m=200, min_pixels=3, min_dates=2, min_fraction=.5):
    """Deduplicate scenes/groups within each day; exact labels stay separate.

    60 m bins are approximate ground-support units, not new independent pixels.
    Clear dates are observation opportunities, not proof of mineral absence.
    """
    if grid_m<60 or min_pixels<1 or min_dates<2 or not 0<min_fraction<=1:
        raise ValueError('Use grid>=60 m, positive support, >=2 dates and fraction in (0,1].')
    clear=defaultdict(set);detections=defaultdict(set)
    def locate(x,y):
        if not (-10000<=x<10000 and -10000<=y<10000):return None
        cell=(int(np.floor(x/grid_m)),int(np.floor(y/grid_m)))
        support=(int(np.floor(x/60)),int(np.floor(y/60)))
        return cell,support
    for s in scenes:
        if not s['audit']['accepted_scene']:continue
        day=s['time'][:10]
        for x,y in s['coverage']:
            p=locate(x,y)
            if p:clear[(p[0],day)].add(p[1])
        for x,y,label in s['points']:
            p=locate(x,y)
            if p:detections[(p[0],day,label)].add(p[1])
    opportunities=defaultdict(set)
    for (cell,day),bins in clear.items():
        if len(bins)>=min_pixels:opportunities[cell].add(day)
    hits=defaultdict(set)
    for (cell,day,label),bins in detections.items():
        if len(bins)>=min_pixels and day in opportunities[cell]:hits[(cell,label)].add(day)
    rows=[]
    for (cell,label),dates in hits.items():
        available=opportunities[cell];fraction=len(dates)/len(available)
        xx=(max(-10000,cell[0]*grid_m)+min(10000,(cell[0]+1)*grid_m))/2
        yy=(max(-10000,cell[1]*grid_m)+min(10000,(cell[1]+1)*grid_m))/2
        lon,lat=INVERSE.transform(xx,yy)
        rows.append(dict(cell_x=cell[0],cell_y=cell[1],lat=lat,lon=lon,label=label,
                         detection_dates=len(dates),clear_dates=len(available),repeat_fraction=fraction,
                         dates=';'.join(sorted(dates)),clear_date_list=';'.join(sorted(available)),
                         review_candidate=len(dates)>=min_dates and fraction>=min_fraction))
    columns=['cell_x','cell_y','lat','lon','label','detection_dates','clear_dates','repeat_fraction','dates','clear_date_list','review_candidate']
    result=pd.DataFrame(rows,columns=columns)
    if len(result):result=result.sort_values(['review_candidate','detection_dates','repeat_fraction'],ascending=False).reset_index(drop=True)
    return result

def run_all(expected, candidate, session, out, download_gb=6):
    """Resolve every frozen granule, check companions and preserve per-scene QA."""
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    cfg=dict(core.DEFAULTS,max_download_gb=download_gb)
    dl=core.Downloader(session,out/'downloads',cfg)
    polygon=candidate['footprint'];bbox=[min(p[0] for p in polygon),min(p[1] for p in polygon),max(p[0] for p in polygon),max(p[1] for p in polygon)]
    scenes=[];audit_rows=[]
    report={'created_utc':datetime.now(timezone.utc).isoformat(),'expected_count':len(expected),'quality_config':cfg,'quality_masks_relaxed':False,
            'notes':'All frozen granules attempted; errors and rejected scenes remain visible. Downloads reused by filename and hashed. Budget applies to newly downloaded bytes this run.'}
    for i,e in enumerate(expected):
        title=e['title'];row={'granule':title,'date':e['start'][:10]}
        try:
            matches=core.catalog('EMITL2BMIN','001',bbox,'2023-01-01','2023-12-31',100,title)
            entry=next(g for g in matches if g.get('title')==title or g.get('producer_granule_id')==title)
            urls=core.data_urls(entry)
            mn=next(u for u in urls if Path(u.split('?')[0]).name==title+'.nc')
            un=next(u for u in urls if Path(u.split('?')[0]).name==title.replace('_MIN_','_MINUNCERT_')+'.nc')
            suffix=title.removeprefix('EMIT_L2B_MIN_001_')
            companion=core.catalog('EMITL2ARFL','001',bbox,'2023-01-01','2023-12-31',50,'EMIT_L2A_RFL_001_'+suffix)
            mask=next(u for g in companion for u in core.data_urls(g) if Path(u.split('?')[0]).name=='EMIT_L2A_MASK_001_'+suffix+'.nc')
            paths=[dl.fetch(u) for u in [mn,un,mask]]
            audit,coverage,points=spatial_scene(paths,polygon,cfg)
            scenes.append({'granule':title,'time':e['start'],'audit':audit,'coverage':coverage,'points':points})
            row.update(status='ACCEPTED' if audit['accepted_scene'] else 'REJECTED_QA',
                       roi_pixels=audit['roi_pixels'],clear_pixels=audit['clear_pixels'],detections=len(points))
        except Exception as exc:
            row.update(status='ERROR',error=core.error_detail(exc))
        audit_rows.append(row)
        report.update(granules=audit_rows,assets=list(dl.assets.values()),
                      complete=len(audit_rows)==len(expected) and not any(r['status']=='ERROR' for r in audit_rows))
        core.save(out/'granule_audit.json',report)
        print(f'{i+1}/{len(expected)} {title}: {row["status"]}',flush=True)
    # Contains only clipped points and sanitized metadata; no session or credentials.
    import gzip
    with gzip.open(out/'spatial_observations.json.gz','wt',encoding='utf-8') as f:json.dump(scenes,f)
    return scenes,report

def make_map(table,candidate,report,out,grid_m):
    import folium
    out=Path(out);m=folium.Map(location=[27.5,41.5],zoom_start=11,tiles='OpenStreetMap')
    folium.PolyLine([[p[1],p[0]] for p in candidate['footprint']],color='black',weight=2,tooltip='Original 20 km study patch').add_to(m)
    coverage=folium.FeatureGroup(name='All observed mineral cells (including single dates)',show=False).add_to(m)
    repeat=folium.FeatureGroup(name='Repeat detections: inspect these areas',show=True).add_to(m)
    features=[]
    for (cx,cy),part in table.groupby(['cell_x','cell_y']):
        bounds=[INVERSE.transform(max(-10000,min(10000,x)),max(-10000,min(10000,y))) for x,y in [(cx*grid_m,cy*grid_m),((cx+1)*grid_m,cy*grid_m),((cx+1)*grid_m,(cy+1)*grid_m),(cx*grid_m,(cy+1)*grid_m),(cx*grid_m,cy*grid_m)]]
        yes=bool(part.review_candidate.any())
        items=''.join('<li>'+html.escape(r.label)+f': {r.detection_dates}/{r.clear_dates} clear dates; '+html.escape(r.dates)+'</li>' for r in part.itertuples())
        popup=('<b>Repeat-mineral inspection cell</b>' if yes else '<b>Observed cell — insufficient repeat support</b>')+'<ul>'+items+'</ul><p>Exact library labels; mixtures stay mixtures. Recurrence within this cell, not proof of the same outcrop or mineral abundance. Check imagery, finer terrain, access, spectroscopy/XRD and rover traction before selecting a route.</p>'
        if not report['complete']:popup='<b>INCOMPLETE: one or more granules failed. Provisional only.</b><br>'+popup
        folium.Polygon([[lat,lon] for lon,lat in bounds],color='#007b67' if yes else '#88939b',weight=1,fill=True,fill_opacity=.45 if yes else .12,popup=folium.Popup(popup,max_width=500)).add_to(repeat if yes else coverage)
        features.append({'type':'Feature','geometry':{'type':'Polygon','coordinates':[bounds]},'properties':{'cell_x':int(cx),'cell_y':int(cy),'review_candidate':yes,'run_complete':report['complete'],'labels':part.label.tolist(),'max_detection_dates':int(part.detection_dates.max()),'role':'inspection area; not a validated rover route'}})
    folium.LayerControl().add_to(m)
    status='All 16 granules checked' if report['complete'] and report['expected_count']==16 else 'INCOMPLETE OR CHANGED RUN — inspect audit'
    m.get_root().html.add_child(folium.Element('<div style="position:fixed;bottom:25px;left:20px;background:white;padding:12px;z-index:9999">'+html.escape(status)+'<br>Green: repeat spectral-library matches<br>200 m cells by default; not approved routes</div>'))
    m.save(str(out/'hail_repeat_map.html'))
    core.save(out/'inspection_cells.geojson',{'type':'FeatureCollection','features':features})
    table=table.copy();table['run_complete']=report['complete']
    table.to_csv(out/'repeat_detections.csv',index=False)
    eligible=table.loc[table.review_candidate.astype(bool)].drop_duplicates(['cell_x','cell_y']).head(20)
    eligible.to_csv(out/'inspection_shortlist.csv',index=False)
    return m,eligible
