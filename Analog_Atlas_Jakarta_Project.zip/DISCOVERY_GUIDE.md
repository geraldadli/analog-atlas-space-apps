# Analog Atlas: fresh discovery with OSEMN

Open **nasa-moon-earth-analog-OSEMN.ipynb** in Kaggle or Colab and run top to bottom.

1. Enable Internet and use a CPU runtime.
2. In Kaggle Secrets, enable `EARTHDATA_USERNAME` and `EARTHDATA_PASSWORD` for EMIT/MODIS downloads. Public terrain and research searches need no credentials. Outside Kaggle, use the same environment variable names.
3. Keep `RUN_FRESH_SEARCH=True`. Default: **384 new patches**, seed `20261114`, 41 cited known-site/region exclusions, and no reuse of the old 96 pilot locations.
4. Read the dataset `head()` previews in **O**, then the short result table in **N**.
5. Read relevant papers. Add local names in `PLACE_ALIASES`, document geographic overlap in `MANUAL_REVIEW`, and rerun the research/result cells.

| Stage | What happens | What to inspect |
|---|---|---|
| Obtain | Fetch Earth/Moon/Mars terrain; show actual first rows | Dataset links, units, coordinates, source files |
| Scrub | Apply known-area exclusions and strict coverage masks | Rejection counts and missing coverage |
| Explore | Map the sampled patches before ranking | Geographic coverage and gaps |
| Model | Compare regional terrain with two planetary patches | Feature differences and sensitivity to weights/grid |
| iNterpret | Search published metadata, read sources, extract follow-up satellites | Where the analogy works, where it fails, next test |

**Limits you can tweak:** sample count/seed; exclusion buffer; open-surface threshold; feature weights; shortlist size; local place-name aliases; satellite dates and transfer caps. Keep masks strict. The 1/2 km terrain grid cannot establish wheel-scale safety, landing hazards or construction strength.

**Data:** Copernicus GLO-90, LOLA, MOLA, WorldCover 2021; EMIT MIN/UNCERT with its L2A mask companion; MOD11A1 temperature and MOD10A1 snow. ESA/USGS references supply exclusions. Natural Earth supplies regional labels; Crossref supplies scholarly metadata. NASA POWER remains an optional context extension and is not downloaded by this fresh workflow. Planetary mineral/thermal/ice pixels are not yet compared.

**Resources:** the local 384-patch acquisition recorded about 1.11 GB of terrain/planetary assets, plus remote land-cover traffic. Reserve several GB for terrain and up to 2 GB transfer per satellite candidate; three candidates can require 6 GB plus processing space. No GPU is required. Cached source files are reused, but failed acquisitions never silently load the old pilot.

**Research limitations:** the public USGS GIS service returned only four points in our check, so the bundled exclusion list also includes 30 ESA catalog entries and supplemental references. Point buffers and broad regional rectangles are conservative choices, not surveyed study boundaries. Crossref can miss conference abstracts, local names and papers lacking indexed abstracts. A no-hit result never certifies novelty. The Kerguelen, Ramon and Tibesti follow-ups demonstrate why checking primary sources matters.

**Local run:** 384 measured patches → 229 with valid land cover → 30 initially passing the surface screen → 27 after the additional cited exclusions → 10 shortlisted. Acquisition used the original 37-entry registry; review expanded it to 41. Both versions and the post-review audit are retained. A new run uses the expanded registry before sampling, so its selected locations can differ even with the same seed.

**Validation:** notebook logic executed locally on real fresh terrain data. The acquisition stage was run separately; the test reused it and skipped the already-installed package setup cell. Public research calls ran. Earthdata credentials were absent, so protected satellite downloads were not rerun here. Kaggle/Colab execution is still to be verified in your runtime. Satellite masks and temperature coverage tests passed unchanged.

**24-hour schedule:** 0–4 obtain/scrub; 4–8 explore/model; 8–14 paper review; 14–20 satellite follow-up; 20–24 explain and share. Service delays may change this schedule.

**Share:** notebook, `plain_results.json`, `literature_screen.json`, `publication_reviews.json`, `scrub_audit.json`, manifests and evidence reports. Shared maps use OpenStreetMap. No CARTO secret is loaded; the supplied notebook has no saved execution outputs.

Sources: [ESA catalog](https://esamultimedia.esa.int/docs/gsp/The_Catalogue_of_Planetary_Analogues.pdf), [USGS analog inventory](https://doi.org/10.5066/P9J72921), [Crossref API](https://www.crossref.org/documentation/retrieve-metadata/rest-api/), [NASA Earthdata login](https://urs.earthdata.nasa.gov/).
